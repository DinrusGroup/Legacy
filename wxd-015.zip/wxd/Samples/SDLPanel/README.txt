
This example requires SDL, see http://www.libsdl.org/

