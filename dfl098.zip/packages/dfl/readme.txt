D Forms Library
Version 0.9.8 (Beta) by Christopher E. Miller
chris@dprogramming.com
See the included license.txt for copyright and license details.

Tested with DMD v1.030 and DMD v1.036.
Tested with DMD v2.014 and DMD v.020.
Tested with Tango 0.99.7 with DMD v1.033.


Installation:

Extract the DFL zip archive so that the files extract into your compiler directory.
It is common to extract to the C:\dmd directory.

Using different compile-time versions:
http://wiki.dprogramming.com/Dfl/CompileVersions


Using:

To use DFL you can simply use the dfl.exe that should be in your \dmd\bin
directory which should already be in your PATH variable from when you setup DMD.

Otherwise, you can use DMD directly, but you will need to use certain switches.
For a normal Windows application, use:
   -L/exet:nt/su:windows:4.0
To include the console window in your application, use this instead:
   -L/exet:nt/su:console:4.0
You will also need to use -debug with dfl_debug.lib,
and -release with dfl.lib, depending on which you wish to use.
Failure to use these switches as appropriate can cause undesired affects.

You do not need to worry about switches and lib files when using dfl.exe.
All you should need is -debug or -release, and -gui or -console.

Example commands:
   dfl -gui helloworld.d
   dmd helloworld.d dfl_debug.lib -debug -L/exet:nt/su:windows:4.0

Or you can use ReBuild (http://www.dsource.org/projects/dsss/wiki/Rebuild).

Or you can use Build/bud (http://dsource.org/projects/build/).

For DFL code examples, look in \dmd\packages\dfl\examples.
Also check out \dmd\packages\dfl\tips.txt and \dmd\packages\dfl\doc\index.html.


Links:

Home: http://www.dprogramming.com/dfl.php
Wiki: http://wiki.dprogramming.com/Dfl/HomePage
Documentation Wiki: http://wiki.dprogramming.com/DflDoc/HomePage
Forum: http://dsource.org/forums/viewforum.php?f=39
IRC: http://www.dprogramming.com/dirclib.php


Versions:

	0.9.8 on 20081115
Updated to work with recent compiler versions.
Added dfl/imagelist.d for image lists.
Added images to ListView.
Added images to TreeView.
Added examples/dirlistview.d to demonstrate image lists with list view.
Added support for D 2.0
Added dfl/toolbar.d with ToolBar control.
Added examples/toolbar.d to demonstrate ToolBar with images from resource.
Fixed Windows issue with GroupBox font.
Added compile-time versions to slim down the library.
Updated dfl.exe, building DFL libs, auto-run bat files starting with dflc_

	0.9.7.01 on 20080313
Updated Tango support to Tango 0.99.5.
Minor changes to work with DMD v1.028.
	0.9.7 on 20080226
Fixed scrolling issue with display rectangle (and docked controls).
Fixed label edit (in-place text editing) for ListView and TreeView.
Now supports dfl.drawing.Picture with Tango.
Added examples/tango/pictureviewer.d demonstrating Picture using Tango.
Property Form.showInTaskbar now works correctly with all border styles.
Key events bubble up the hierarchy if they are not handled.
Form.dialogResult set to non-NONE now closes the form if shown with showDialog.
Button click event now sets Form.dialogResult to the Button.dialogResult.
Updated dfl.exe; now supports Tango.
Fixed critical MDI issue.
Control.onKeyPress and keyPress now take KeyPressEventArgs.
Fixed MenuItem.radioCheck.
Added function Control.disableVisualStyle to toggle visual style per control.
Updated Tango support to Tango 0.99.4.
Fixed mnemonics (control, menu); added Control.processMnemonic.
Updated dfl.exe; bug fixes and more options.
Added Tangobos support.
Form.onLoad/load called at different time: before first show.
Added Control.selectNextControl.
Reimplemented tab ordering, mnemonics, and other dialog processing.
Changed onVisibleChanged/visibleChanged.
Changed MDI activation.
Bug fixes.

	0.9.6 on 20070806
Added ability to custom sort and re-sort ListView.
Added examples/listviewdirsort.d to demonstrate advanced ListView sorting.
Added dfl/statusbar.d with StatusBar control.
Added examples/status.d to demonstrate StatusBar.
Added property Application.userAppDataBasePath.
Added class Screen to dfl.drawing.
Control handles now recreate automatically if a property change requires it.
License updated in license.txt
	0.9.5.03 on 20070419
Minor changes to work with DMD v1.012.
	0.9.5.02 on 20070326
Added examples/regextester.d
More fixes.
	0.9.5.01 on 20070318
Updated support to Tango 0.96 beta2; or version=DFL_TANGO0951beta1 for 0.95.1 beta1.

	0.9.5 on 20070304:
Better support for unicode internally.
Fixed menu item index bug.
Changed how radio buttons auto check (and uncheck).
Changed how enter and escape key events are handled.
Added class MemoryGraphics.
Added copyTo() functions to Graphics.
Added property Application.autoCollect, enabled by default, to invoke GC when idle.
Added workaround for with() issues ( http://wiki.dprogramming.com/Dfl/Dmd0161 ).
Added workaround for Windows 98 RichTextBox issue.
Added property Splitter.movingGrip.
Changed how the default Control font is obtained.
Fixed click event bug when hidden controls were involved.
Implemented Form's maximumSize and minimumSize properties.
Fixed bug in Control.visible/show changing the z-order.
Changed Control layout code; dock and onLayout affected.
Fixed bug in Application.doEvents() returning incorrect value in some cases.
Many changes to how controls are shown and hidden; onVisibleChanged affected.
Label text can alpha blend with the background color.
License updated in license.txt
Form properly fires closing and closed events for modal dialogs.
Started support for control/form scaling. autoScale is default disabled but may change.
Added class ProgressBar.
Added examples/progress.d to demonstrate ProgressBar.
Panel now derives from ContainerControl instead of ScrollableControl.
Event handler parameter type contravariance; trial feature.
Added SystemIcons to dfl/drawing.d.
Added property Application.resources and module dfl.resources.
Added examples/rctest.d to demonstrate resource loading.
Updated dfl.exe; now performs version checks and expands file name wildcards.
Fixed Form system/window menus; used to show items not applicable to the styles.
String/text clipboard/Data formats are able to be converted automatically.
Moved dfl.winapi, dfl.utf, dfl.com and dfl.wincom to internal directory.
Directory structure now excludes dmd directory. Drop files in compiler directory.
Updated all "object collections"; changes include renaming count to length.
Adding items to menus has been modified. Menu.setDFL092() added for compatibility.
Added examples/dirlist.d to demonstrate FolderBrowserDialog.
Added support for Tango (http://dsource.org/projects/tango).
Implemented DataFormats.fileDrop.
Added examples/filedrop.d to demonstrate dragging and dropping files.
Splitter updated; now gives visual cues.
Finishing up Unicode/UTF support.
Added scrolling support.
Added examples/scroller.d to demonstrate scrolling.
Updated dfl.exe; will handle rebuilding DFL lib files for you.
Removed lib directory and default DFL lib files as they cause versioning issues.
Created a simple DFL installer.

	0.9.2 on 20060202:
Better support for build (http://dsource.org/projects/build/).
Updated dfl.exe; now sets version=DFL_EXE.
Added classes AsyncSocket, AsyncTcpSocket and AsyncUdpSocket to dfl.socket.
Added examples/dflhtmlget.d to demonstrate sockets, hosts, rich text, etc.
Added property Button.image to show an image on the button instead of text.
	0.9.1 on 20060106:
Added examples/droplist.d to demonstrate advanced drag and drop.
Application.doEvents() now returns false if the application should exit.
Some support for DLLs. See examples/dlltest.d.
Rewrote Label control and added features.
Controls can inherit backColor, foreColor, leftToRight, font and cursor.
Added onReflectedMessage() to process messages reflected from parent.
Added class Picture which can load different image formats.
Added debug and release lib files. dfl.exe uses either as appropriate.
Form is now hidden by default and Application.run() shows the mainForm.
Fixed up some of the examples.
Added members to Font.
Added class FontDialog.
Updated examples/dnote.d to demonstrate FontDialog.
Added "Windows hung" workaround.

	0.9 on 20050606:
Control.invoke() and Control.invokeRequired() are finished. See tips.txt/Other.
Added examples/invoke.d to demonstrate Control.invoke() with multiple threads.
Added class Cursors.
Drag and drop works.
Added examples/drop.d to demonstrate drag and drop.
MDI works.
Added examples/mdi.d to demonstrate MDI.
Revised the directory layout. It is recommended to delete old DFL files first.
Added examples/tiplist.d shows how to use different tooltip text for list items.
Added class TabControl.
Added examples/tabs.d to demonstrate TabControl.
Added class ColorDialog.
Updated examples/paint.d to demonstrate ColorDialog.
Added class ListView.
Added examples/listview.d to demonstrate ListView.

	0.8 on 20050224:
Started support for UTF-8.
Updated examples/dnote.d to support UTF-8.
Added Application.enableVisualStyles() to enable XP styles without a manifest file.
Finished enum Keys.
MessageBox.show() has been renamed to msgBox() to avoid future conflicts.
TextBox and RichTextBox should now fully support UTF-8.
Added Form.addShortcut() and Form.removeShortcut() for shortcut keys.
Added examples/shortcut.d to demonstrate shortcut keys.
Fixed a Control bounds (window rect) issue.
Added class Bitmap to drawing.d.
Added dfl/picturebox.d with PictureBox control.
Added examples/pictureviewer.d, a simple bitmap viewer.
Added class FolderBrowserDialog.
Changed behavior of default exception dialog to pause message loop.
Removed anchoring. It was always buggy. It's easy to do manually with the layout event.
Modal dialog close button hides it and sets dialogResult to DialogResult.CANCEL.

	0.7 on 20041215:
Added SystemColors to dfl/drawing.d.
Added dfl/combobox.d with ComboBox control.
Added examples/combo.d to demonstrate ComboBox.
XP styles should work better with Button.
Added dfl/treeview.d with TreeView control.
Added examples/treeview.d to demonstrate TreeView.
Rectangle has been renamed to Rect to avoid conflicts.

	0.6 on 20041130:
Removed dfl/guid.d.
Added dfl/tooltip.d. Note that I hate tooltips :)
Added examples/tip.d to demonstrate tooltips.
Fixed radio button freeze.
Added more Graphics drawing functions to dfl/drawing.d.
Added examples/draw.d to demonstrate the drawing functions.
Control no longer redraws on resize by default. Use resizeRedraw to change.
Minor changes to work with DMD v0.108.

	0.5 on 20041114:
FormStartPosition.CENTER_PARENT makes sure the Form is on the screen.
Added asynchronous host resolving functions to dfl/socket.d.
Form.formBorderStyle was partially broken: Windows adds styles during creation.
GroupBox would fail if created before a Button.
Minor changes to work with DMD v0.106.

	0.4 on 20041017:
ListBox is fixed. No longer only supports char[] items. Owner draw works.
Added more to dfl/drawing.d. Font construction; brushes.
Added dfl/richtextbox.d. Windows 95 needs riched20.dll.
Added a couple more small examples.

	0.3 on 20041008:
Form's acceptButton was receiving 2 click events instead of 1.
Added examples/rps_server.d and examples/rps.d to demonstrate dfl/socket.d.
Added dfl/guid.d for GUIDs.
Added dfl/containers.d to simplify some things like ListControl's items.
TextBoxBase's multiline and wordWrap properties should work correctly now.
Other parts of TextBoxBase and TextBox are fixed up.
Form's menu will redraw itself when modified.
Added dfl/data.d and dfl/clipboard.d to access the clipboard.
Added dfl/commondialog.d and dfl/filedialog.d.
Added examples/dnote.d -- a working program showing several features.
borderStyle properties redraw the control properly.
Paint events are sent to standard Windows controls.
Added the new documentation to doc/.

	0.2 on 20040816:
Fixed context menus.
TextBoxBase's context menu is now a DFL menu.
Added dfl/registry.d.
Added dfl/notifyicon.d.
Added examples/tray.d to show usage of NotifyIcon class.
Added registry examples to examples/dfltest.d.

	0.1 on 20040714:
First public alpha release.

