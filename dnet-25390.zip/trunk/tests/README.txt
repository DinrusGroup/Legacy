To run the tests from the Visual Studio IDE, right click on tests, go to the Properties menu and 
under Configuration Properties --> Debugging, set Working Dir to: $(OutDir)

Right click on tests againg, and select Debug --> Start new instance.