// $Id$
// Copyright (c) 2009 Cristian L. Vlasceanu

/*****
This license governs use of the accompanying software. If you use the software, you
accept this license. If you do not accept the license, do not use the software.

1. Definitions
The terms "reproduce," "reproduction," "derivative works," and "distribution" have the
same meaning here as under U.S. copyright law.
A "contribution" is the original software, or any additions or changes to the software.
A "contributor" is any person that distributes its contribution under this license.
"Licensed patents" are a contributor's patent claims that read directly on its contribution.

2. Grant of Rights
(A) Copyright Grant- Subject to the terms of this license, including the license conditions and limitations in section 3,
each contributor grants you a non-exclusive, worldwide, royalty-free copyright license to reproduce its contribution, 
prepare derivative works of its contribution, and distribute its contribution or any derivative works that you create.
(B) Patent Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, 
each contributor grants you a non-exclusive, worldwide, royalty-free license under its licensed patents to make, have made,
use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the software or derivative works of the 
contribution in the software.

3. Conditions and Limitations
(A) No Trademark License- This license does not grant you rights to use any contributors' name, logo, or trademarks.
(B) If you bring a patent claim against any contributor over patents that you claim are infringed by the software,
your patent license from such contributor to the software ends automatically.
(C) If you distribute any portion of the software, you must retain all copyright, patent, trademark,
and attribution notices that are present in the software.
(D) If you distribute any portion of the software in source code form, you may do so only under this license by 
including a complete copy of this license with your distribution. If you distribute any portion of the software 
in compiled or object code form, you may only do so under a license that complies with this license.
(E) The software is licensed "as-is." You bear the risk of using it. The contributors give no express warranties,
guarantees or conditions. You may have additional consumer rights under your local laws which this license cannot change.
To the extent permitted under your local laws, the contributors exclude the implied warranties of merchantability,
fitness for a particular purpose and non-infringement.
*****/
#include "enum.h"
#include "mtype.h"
#include "backend.net/array.h"
#include "backend.net/irstate.h"
#include "backend.net/type.h"       // for className
#include "backend.net/msil/enumemit.h"


namespace {
    ///<summary>
    /// Emit the IL for one enum member
    ///</summary>
    class EnumElem : public elem
    {
        Enum& e_;
        EnumMember& mem_;

        elem* emitILAsm(std::wostream& out)
        {
            indent(out) << ".field public static literal valuetype ";
            out << className(e_.getDecl());
            out << " " << mem_.toChars() << " = " << e_.getMemberTYPE().name();
            out << "(" << mem_.value->toInteger() << ")\n";
            return this;
        }
    public:
        EnumElem(Enum& e, EnumMember& mem) : e_(e), mem_(mem)
        {
        }
    };
}


Enum::Enum(EnumDeclaration& decl, unsigned depth)
    : decl_(decl)
    , block_(NULL, decl.loc, depth + 1)
    , memTYPE_(toILType(decl.loc, decl.memtype))
{
    decl.csym = this;
    if (!decl.memtype->isintegral() || decl.memtype->ty == Tchar)
    {
        std::string err = memTYPE_.name();
        err += " is not allowed as an enumerated base type by ";
        err += BackEnd::instance().name();
        BackEnd::fatalError(decl.loc, err.c_str());
    }
    ArrayAdapter<Dsymbol*> members(decl.members);
    for (ArrayAdapter<Dsymbol*>::iterator i = members.begin(); i != members.end(); ++i)
    {
        assert(*i);
        if (!DEREF(*i).csym)
        {
            if (EnumMember* mem = (*i)->isEnumMember())
            {
                block_.add(*new EnumElem(*this, *mem));
            }
        }
    }
}



elem* Enum::emitILAsm(std::wostream& out)
{
    indent(out << "\n");
    out << ".class value " << decl_.prot() << "auto ansi sealed ";
    out << className(decl_) << " extends [mscorlib]System.Enum\n";
    indent(out) << "{\n";
    block_.indent(out) << ".field public specialname rtspecialname ";
    out << memTYPE_.name() << " value__\n";
    block_.emitILAsm(out);
    indent(out) << "} // end of " << className(decl_) << "\n\n";
    return this;
}
