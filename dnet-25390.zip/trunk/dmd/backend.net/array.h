#ifndef ARRAY_H__BFC198A6_D6B7_4073_9E9C_5F20A532BE69
#define ARRAY_H__BFC198A6_D6B7_4073_9E9C_5F20A532BE69
// -*- tab-width: 4; indent-tabs-mode: nil;  -*-
// vim: tabstop=4:softtabstop=4:expandtab:shiftwidth=4
//
// $Id$
//
// Copyright (c) 2008 Cristian L. Vlasceanu

/*****
This license governs use of the accompanying software. If you use the software, you
accept this license. If you do not accept the license, do not use the software.

1. Definitions
The terms "reproduce," "reproduction," "derivative works," and "distribution" have the
same meaning here as under U.S. copyright law.
A "contribution" is the original software, or any additions or changes to the software.
A "contributor" is any person that distributes its contribution under this license.
"Licensed patents" are a contributor's patent claims that read directly on its contribution.

2. Grant of Rights
(A) Copyright Grant- Subject to the terms of this license, including the license conditions and limitations in section 3,
each contributor grants you a non-exclusive, worldwide, royalty-free copyright license to reproduce its contribution, 
prepare derivative works of its contribution, and distribute its contribution or any derivative works that you create.
(B) Patent Grant- Subject to the terms of this license, including the license conditions and limitations in section 3, 
each contributor grants you a non-exclusive, worldwide, royalty-free license under its licensed patents to make, have made,
use, sell, offer for sale, import, and/or otherwise dispose of its contribution in the software or derivative works of the 
contribution in the software.

3. Conditions and Limitations
(A) No Trademark License- This license does not grant you rights to use any contributors' name, logo, or trademarks.
(B) If you bring a patent claim against any contributor over patents that you claim are infringed by the software,
your patent license from such contributor to the software ends automatically.
(C) If you distribute any portion of the software, you must retain all copyright, patent, trademark,
and attribution notices that are present in the software.
(D) If you distribute any portion of the software in source code form, you may do so only under this license by 
including a complete copy of this license with your distribution. If you distribute any portion of the software 
in compiled or object code form, you may only do so under a license that complies with this license.
(E) The software is licensed "as-is." You bear the risk of using it. The contributors give no express warranties,
guarantees or conditions. You may have additional consumer rights under your local laws which this license cannot change.
To the extent permitted under your local laws, the contributors exclude the implied warranties of merchantability,
fitness for a particular purpose and non-infringement.
*****/
#include "root.h"
#include <algorithm>

/// Adapt DMD front-end Array to STL-like container
template<typename T>
class ArrayAdapter
{
    const Array* a_;

    T* _first() const { return a_ ? (T*)(&a_->data[0]) : NULL; }
    T* _last () const { return a_ ? (T*)(&a_->data[a_->dim]) : NULL; }

public:
    typedef T* iterator;
    typedef const T* const_iterator;

    explicit ArrayAdapter(Array* a = NULL) : a_(a) { }
    explicit ArrayAdapter(const Array& a) : a_(&a) { }

    size_t size() const { return a_ ? a_->dim : 0; }
    bool empty() const { return size() == 0; }

    iterator begin() { return _first(); }
    iterator end() { return _last(); }
    const_iterator begin() const { return _first(); }
    const_iterator end() const { return _last(); }

    T operator[](size_t i) const
    {
        return (T&)(a_->data[i]);
    }

    T find(T val) const
    {
        const_iterator e = end();
        const_iterator i = std::find(begin(), e, val);
        if (i == e)
        {
            return T();
        }
        return *i;
    }
};

#endif // ARRAY_H__BFC198A6_D6B7_4073_9E9C_5F20A532BE69
