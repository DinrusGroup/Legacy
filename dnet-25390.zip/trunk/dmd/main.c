extern int _Dmain();

int main() { return _Dmain(); }
