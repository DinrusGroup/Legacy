
#include "root.h"
#ifdef alloca
 #undef alloca
#endif
#include "../idgen/id.c"