// JAK 19980521 =>

#if __DMC__ || __RCC__
#pragma once
#endif

#ifndef RC_INVOKED
#pragma pack(__DEFALIGN)
#endif

#include <win32\scdefs.h>
#include <win32\zmouse.h>

#ifndef RC_INVOKED
#pragma pack()
#endif
// JAK 19980521 <=
