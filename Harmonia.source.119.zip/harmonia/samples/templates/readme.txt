Templates of various types of applications:
Frame based.
HTML page based.
Dialog based.
Tray based mini application.