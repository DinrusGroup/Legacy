// C main calling C compiled rule set using lmcMain to process args
#include <lm/lmc.h>
#include <lm/licenseGnuGPLv2.h>
#include <stdio.h>

int lmcMain(int argc, char ** argv);

int main(int argc, char ** argv)
{
    printf("hello from calcMainc\n");
    int result = lmcMain(argc, argv);
    return result;
}

element whatabout(stream s, element x, element y, element z) { 
  printf("--- whatabout %10s %10s %10s %8g\n", toCstring(s, x), toCstring(s, y), toCstring(s, z), toNum(s, toVal(s, z))); 
  var v = toVar(s, z);
  
  if(v) {
    printf("%60s: %20s\n", "variable name"                                               , toCstring(s, z));
    printf("%60s: %20g\n", "variable value"                                              , toNum(s, toVal(s, z)));
    printf("%60s: %20g\n", "originating state index"                                     , toNum(s, varSi (s, v)));
    printf("%60s: %20s\n", "grammar of originating context"                              , toCstring(s, varGsy (s, v)));
    printf("%60s: %20s\n", "L symbol in mismatch that started the originating context"   , toCstring(s, varLsy(s, v)));
    printf("%60s: %20s\n", "R symbol in mismatch that started the originating context"   , toCstring(s, varRsy(s, v)));
    printf("%60s: %20s\n", "name of input file or source object"                         , toCstring(s, varIfn(s, v)));
    printf("%60s: %20g\n", "absolute input position"                                     , toNum(s, varCp (s, v)));
    printf("%60s: %20g\n", "line number"                                                 , toNum(s, varLn (s, v)));
    printf("%60s: %20g\n", "character position in line"                                  , toNum(s, varCn (s, v)));
    }
    
  return null;
  }
  
element thisabout(stream s, element x, element y, element z) { 
  printf("--- thisabout %10s %10s %10s %8g\n", toCstring(s, x), toCstring(s, y), toCstring(s, z), toNum(s, toVal(s, z))); 
  return null;
  }
