#include <lm/licenseGnuGPLv2.h>
#ifndef LMC
#define LMC
#define null ((void*)0)

typedef int bool;
typedef unsigned           uint;
typedef double             lmnum;
typedef long long          d_int;
typedef unsigned long long lunum;

typedef struct _lmr * stream;
typedef void * mode;
typedef void * opnd;
typedef void * var;
typedef void * engine;
typedef void * element;

typedef mode    (*lmeString)(stream);
typedef element (*lmnFunc)  (stream);

struct _lmr {
  mode      sm;    // stream mode  
  uint	    ci;    // code index
  element   sy;    // current symbol
  element   sv;    // current value
  element   rv;    // return value from machine
  opnd      xs;    // operand stack
  var       av;    // list of all variables
  engine    lm;    // the engine
  
  element * tt; 
  element * mt; 
  element * dt; 
  element * vt; 
  element * xt; 
  element * nt;
  element * st;
  element * ft;
  
  element start;
  element eof;
  element nil;
  element zlm;
  element put;
  element mark;
  element dropfn;
  element getfn;
  element strfn;
  element actfn;
  element bindfn;
  element takefn;
  element donefn;
  element injfn;
  element appendfn;
  element repeatfn;
  element optionfn;
  element repeatfx;
  element optionfx;
};

extern  element mark   (stream s); 
extern  element args   (stream s); 
extern  element push   (stream s, element x); 
extern  element pop    (stream s);  

extern  lmnum   toNum      (stream s, element x);
extern  char *  toCstring  (stream s, element x);

extern  element toVal      (stream s, element x);
extern  var     toVar      (stream s, element x);

//extern  element varSi      (stream s, var     v);
//extern  element varGsy     (stream s, var     v);
//extern  element varLsy     (stream s, var     v);
//extern  element varRsy     (stream s, var     v);
//extern  element varIfn     (stream s, var     v);
//extern  element varCp      (stream s, var     v);
//extern  element varLn      (stream s, var     v);
//extern  element varCn      (stream s, var     v);
  
extern  element octal      (stream s, ...);
extern  element binary     (stream s, ...);
extern  element hex        (stream s, ...);
extern  element num        (stream s, ...);
extern  element usym       (stream s, ...);
extern  element ulsym      (stream s, ...);
extern  element uusym      (stream s, ...);
extern  element ssym       (stream s, ...);
extern  element slsym      (stream s, ...);
extern  element susym      (stream s, ...);
extern  element variable   (stream s, ...);
extern  element urn        (stream s, ...);
extern  element urd        (stream s, ...);
extern  element lcase      (stream s, ...);
extern  element ucase      (stream s, ...);
extern  element buffer     (stream s, ...);

extern  element varSi      (stream s, ...);
extern  element varGsy     (stream s, ...);
extern  element varLsy     (stream s, ...);
extern  element varRsy     (stream s, ...);
extern  element varIfn     (stream s, ...);
extern  element varCp      (stream s, ...);
extern  element varLn      (stream s, ...);
extern  element varCn      (stream s, ...);
extern  element lmVersion  (stream s);
extern  element lmDate     (stream s);

extern  void    neednt (stream s, int n); 
extern  void    needmt (stream s, int n);
extern  void    needdt (stream s, int n);
extern  void    needtt (stream s, int n);
extern  void    needvt (stream s, int n);
extern  void    needxt (stream s, int n);
extern  void    needst (stream s, int n);
extern  void    needft (stream s, int n);
  
extern  element makent (stream s, int i, int      x); 
extern  element makemt (stream s, int i, char *    x); 
extern  element makedt (stream s, int i, char *    x);
extern  element makett (stream s, int i, char *    x);
extern  element makevt (stream s, int i, char *    x);
extern  element makext (stream s, int i, char *    x); 
extern  element makest (stream s, int i, lmeString x);
extern  element makeft (stream s, int i, lmnFunc   x);
   
extern  uint M(int p);
extern  uint L(int p);
extern  uint R(int p);
extern  uint B(int p);

extern  void  define(stream s, char * rule);

extern  mode def (stream s, element gr, uint pr, 
    uint lw, uint rk, uint ln, uint rn, element lx, element rx, lmeString lh, lmeString rh, char * fi, uint li
    );
  
extern  void tra(stream s, char * side, int rule, int line);
extern  void tr (stream s, char * t, void * x);

extern  void eNtr(stream s, char * what, int unit, int line);
extern  void zZtr(stream s, char * what, int unit, int line);
extern  void zVtr(stream s, char * what, int unit, int line);
extern  void mVtr(stream s, char * what, int unit, int line);
extern  void bVtr(stream s, char * what, int unit, int line);
extern  void tVtr(stream s, char * what, int unit, int line);
extern  void rXtr(stream s, char * what, int unit, int line);
extern  void o1tr(stream s, char * what, int unit, int line);
extern  void iNtr(stream s, char * what, int unit, int line);
extern  void dNtr(stream s, char * what, int unit, int line);
extern  void oUtr(stream s, char * what, int unit, int line);
    
extern  void aPtr(stream s, char * what, int unit, int line);
extern  void vRtr(stream s, char * what, int unit, int line);
extern  void aLtr(stream s, char * what, int unit, int line);
extern  void eAtr(stream s, char * what, int unit, int line);
extern  void rNtr(stream s, char * what, int unit, int line);
extern  void rTtr(stream s, char * what, int unit, int line);
  
#ifndef DEBUG
#define tra(s, t, r, l)
#define eNtr(s, what, unit, line)
#define zZtr(s, what, unit, line)
#define zVtr(s, what, unit, line)
#define mVtr(s, what, unit, line)
#define bVtr(s, what, unit, line)
#define tVtr(s, what, unit, line)
#define rXtr(s, what, unit, line)
#define o1tr(s, what, unit, line)
#define iNtr(s, what, unit, line)
#define dNtr(s, what, unit, line)
#define oUtr(s, what, unit, line)
    
#define aPtr(s, what, unit, line)
#define vRtr(s, what, unit, line)
#define aLtr(s, what, unit, line)
#define eAtr(s, what, unit, line)
#define rNtr(s, what, unit, line)
#define rTtr(s, what, unit, line)
#endif

extern  int     sci (stream s);
extern  mode    ssm (stream s);
extern  mode    ret (stream s);
extern  element snt (stream s, int n);
extern  element smt (stream s, int n);
extern  element sdt (stream s, int n);
extern  element stt (stream s, int n); 
extern  element svt (stream s, int n);
extern  element sxt (stream s, int n);
extern  element sst (stream s, int n);

extern  mode eN(stream s, uint i, element x);
extern  mode zZ(stream s, uint i, element x);
extern  mode zV(stream s, uint i, element x);
extern  mode mV(stream s, uint i, element x); 
extern  mode bV(stream s, uint i, element x); 
extern  mode tV(stream s, uint i, element x);
extern  mode rX(stream s, uint i, element x); 
extern  mode o1(stream s, uint i, element x);
extern  mode iN(stream s, uint i, element x);
extern  mode dN(stream s, uint i, element x);
extern  mode oU(stream s, uint i, element x);
  
extern  mode aP(stream s, uint i, element x);
extern  mode vR(stream s, uint i, element x);
extern  mode aL(stream s, uint i, element x);
extern  mode eA(stream s, uint i, element x); 
extern  mode rN(stream s, uint i, element x);
extern  mode rT(stream s, uint i, element x);
  
#ifndef NOMACRO
#define sci(s)       (s->ci)
#define ssm(s)       (s->sm)
#define smt(s, i) (s->mt[i])
#define sdt(s, i) (s->dt[i])
#define stt(s, i) (s->tt[i])
#define svt(s, i) (s->vt[i])
#define sxt(s, i) (s->xt[i])
#define snt(s, i) (s->nt[i])
#define sst(s, i) (s->st[i])

#define mV(s, i, x) (s->ci = i, s->sy = x, s->sm)
#define aP(s, i, x) (s->ci = i, apply  (s, x))
#define vR(s, i, x) (s->ci = i, theRef (s, x))
#define aL(s, i, x) (s->ci = i, allRef (s, x))
#define eA(s, i, x) (s->ci = i, eachRef(s, x))
//#define rT(s, i, x) (s->ci = i, null)
#endif

extern  mode apply      (stream s, element  x);
extern  mode theRef     (stream s, element  x);
extern  mode allRef     (stream s, element  x);
extern  mode eachRef    (stream s, element  x);

extern  element newvar  (stream s, element k, element v);
extern  element gv      (stream s, element  x);
  
extern  element gq      (stream s, element x);  
extern  element gs      (stream s, element x);
extern  element gm      (stream s, element x);
extern  element gd      (stream s, element x);
extern  element gn      (stream s, lmnum   x);

extern  element add(stream s, element x, element y);
extern  element sub(stream s, element x, element y);
extern  element mul(stream s, element x, element y);
extern  element div(stream s, element x, element y);
extern  element mod(stream s, element x, element y);

extern  bool    tf(element x);

extern  element and(stream s, element x, element y);
extern  element or (stream s, element x, element y);
extern  element xor(stream s, element x, element y);

extern  element inA(stream s, element x, element y);
extern  element eq (stream s, element x, element y);
extern  element ne (stream s, element x, element y);
extern  element lt (stream s, element x, element y);
extern  element gt (stream s, element x, element y);
extern  element le (stream s, element x, element y);
extern  element ge (stream s, element x, element y);

extern  element pos(stream s, element x);
extern  element neg(stream s, element x);
extern  element inv(stream s, element x);
extern  element not(stream s, element x);

extern  element preinc  (stream s, element x);
extern  element predec  (stream s, element x);
extern  element postinc (stream s, element x);
extern  element postdec (stream s, element x);

extern  element assign   (stream s, element x, element y);
extern  element addassign(stream s, element x, element y);
extern  element subassign(stream s, element x, element y);
extern  element mulassign(stream s, element x, element y);
extern  element divassign(stream s, element x, element y);
extern  element modassign(stream s, element x, element y);
extern  element andassign(stream s, element x, element y);
extern  element orassign (stream s, element x, element y);
extern  element xorassign(stream s, element x, element y);
 
extern  element slz(stream s, element x);
extern  element sli(stream s, element x, element y, element c);
extern  element idx(stream s, element x, element y);
extern  element dot(stream s, element x, element y);
extern  element fn      (stream s, ...);
extern  element cell    (stream s,element x, element v); 
extern  element array   (stream s, ...);

extern look(char * s, void *p);
extern dumptable(void *p, lmnum n);

#endif
