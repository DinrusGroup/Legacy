// C main calling C compiled rule set using lmcMain to process args
#include <lm/lmc.h>
#include <lm/licenseGnuGPLv2.h>

int lmcMain(int argc, char ** argv);

int main(int argc, char **argv) {
  int result = lmcMain(argc, argv);
  return result;
}
