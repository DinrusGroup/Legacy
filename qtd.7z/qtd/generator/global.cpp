#include "global.h"

Global global;

Global::Global()
{
}
