#include <QtCore/QtCore>
#include <QtGui/QtGui>
#include <QtNetwork/QtNetwork>
#include <QtSql/QtSql>
#include <QtSvg/QtSvg>
#include <QtXml/QtXml>

#ifndef QT_NO_XMLPATTERNS
#  include <QtXmlPatterns/QtXmlPatterns>
#endif

#ifndef QT_NO_WEBKIT
#  include <QtWebKit/QtWebKit>
#endif
/*
#ifndef QT_NO_PHONON
#  include <phonon/phonon>
#endif
*/
#ifndef QT_NO_OPENGL
#include <QtOpenGL/QtOpenGL>
#endif
