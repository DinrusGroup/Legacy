#! /bin/bash

dmd trivialwizard.d -I../../../ -I../../../qt/d1 -L-L../../../lib -L-lqtdgui -L-lqtdcore -L-lQtCore -L-lQtGui -oftrivialwizard
