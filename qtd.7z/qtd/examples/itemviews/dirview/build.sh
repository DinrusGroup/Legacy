#! /bin/bash
#rcc mainwindow.qrc -o mainwindow_rcc.cpp
#g++ -c -I/usr/share/qt4/mkspecs/linux-g++ -I. -I/usr/include/qt4/QtCore -I/usr/include/qt4/QtGui -I/usr/include/qt4 -I/usr/X11R6/include mainwindow_rcc.cpp
dmd main.d -I../../../ -I../../../qt/d1 -L-L../../../lib -L-lqtdgui -L-lqtdcore -L-lQtCore -L-lQtGui -ofdirview