
		The D Programming Language
		Compiler Front End Source
		Copyright (c) 1999-2002, by Digital Mars
		www.digitalmars.com
		All Rights Reserved


This is the source code to the front end Digital Mars D compiler.
It covers the lexical analysis, parsing, and semantic analysis
of the D Programming Language defined in the documents at
www.digitalmars.com/d/

The optimizer, code generator, and object file generator are not part
of this source, hence the source does not currently constitute a complete,
compilable program. However, many people have expressed a strong interested
in producing a D compiler with the GNU compiler sources. This release should
enable that.

These sources are free, they are redistributable and modifiable
under the terms of the GNU General Public License (attached as gpl.txt),
or the Artistic License (attached as artistic.txt).

It does not apply to anything else distributed by Digital Mars,
including D compiler executables.

-Walter Bright
