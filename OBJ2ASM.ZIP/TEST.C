typedef unsigned int word;

static char*lp_uilpsz(word _word, char* _charstar)
{
  int si;
  unsigned char uc;
  signed char sc;

  _word = _word;
  _charstar = _charstar;
  return(_charstar);
}

static word ui_uilpsz(word _word, char* _charstar)
{
  int si;
  unsigned char uc;
  signed char sc;

  _word = _word;
  _charstar = _charstar;
  return(_word);
}
