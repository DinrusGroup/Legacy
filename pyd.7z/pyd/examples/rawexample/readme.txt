This is an example of a simple Python extension written with the raw Python/C
API, using CeleriD. Note that this module's setup.py specifies the raw_only
option.

Execute the conventional distutils command
    python setup.py build
to build.

Then execute
    python test.py
to exercise this example extension.
