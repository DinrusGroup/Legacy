This example runs through many of the advanced features of Pyd.

Execute the conventional distutils command
    python setup.py build
to build.

Then execute
    python test.py
to exercise this example extension.
