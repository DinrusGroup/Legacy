This example illustrates the basic automatic inheritance support provided by
Pyd.

Execute the conventional distutils command
    python setup.py build
to build.

Then execute
    python test.py
to exercise this example extension.
