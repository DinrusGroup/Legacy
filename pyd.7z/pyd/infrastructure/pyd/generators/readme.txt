Some of these are obsolete at this point, but here are some Python scripts that
were used to generate some of the template code in Pyd.
