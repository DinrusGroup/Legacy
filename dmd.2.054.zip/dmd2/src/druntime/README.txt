The source code repository for Druntime is:
https://github.com/D-Programming-Language/druntime

Druntime is the minimum library required to support the D programming
language. It includes the system code required to support the garbage
collector, associative arrays, exception handling, array vector operations,
startup/shutdown, etc.
