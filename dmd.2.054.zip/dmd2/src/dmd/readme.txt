
		The D Programming Language
		Compiler Front End Source
		Copyright (c) 1999-2009, by Digital Mars
		http://www.digitalmars.com
		All Rights Reserved


This is the source code to the front end Digital Mars D compiler.
It covers the lexical analysis, parsing, and semantic analysis
of the D Programming Language defined in the documents at
http://www.digitalmars.com/d/

These sources are free, they are redistributable and modifiable
under the terms of the GNU General Public License (attached as gpl.txt),
or the Artistic License (attached as artistic.txt).

The optimizer and code generator sources are 
covered under a separate license, backendlicense.txt.

It does not apply to anything else distributed by Digital Mars,
including D compiler executables.

-Walter Bright
