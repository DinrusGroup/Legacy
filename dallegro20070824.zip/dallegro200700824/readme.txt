This is a distribution of the Allegro library for the D programming language.


VERSION
-------

2.0 beta 6, for Allegro 4.2.2



REQUIREMENTS
------------
DMD 1.005 or later.
Alternatively, GDC 0.23 or later.

The DBlocks demo game requires at least DMD 1.014 or GDC 0.24.

DMD 1.018-1.020 will compile everything but the Allegro demo.

DAllegro is made to support both version 1 and 2 of the D language, but DBlocks
currently won't build with D 2 compilers.

DAllegro is  compatible with both the Phobos and Tango libraries.

For compiling the examples etc. on Windows you need bud, aka build.  On Unix,
GNU make is required instead.

DMD: http://www.digitalmars.com/d/changelog.html
GDC: http://dgcc.sourceforge.net/
bud: http://www.dsource.org/projects/build



INSTALLATION
------------
You need to copy the 'allegro' directory either into dmd/import, or to the
directory of the project you plan to use it with.  The other directories can
stay under the 'dallegro' directory, they are not needed to build programs that
use dallegro.

On Windows:
The LIB files can go in directory dmd/lib.
Put alleg42.dll and alld42.dll either in the dir where your game's executable
is, or in Windows/System32.  If you do the latter, all your games can use
the same files.  alld42.lib is the debug version.

If you have got a .dll file but no .lib file, you can create one like this:

1. Download ftp://ftp.digitalmars.com/bup.zip, and extract implib.exe somewhere
   in you path.
2. Run 'implib /s alleg.lib alleg42.dll'.

If you want a static link library version of DAllegro, you can use make-lib.bat
to create one.  Just running 'make-lib' will create dalleg.lib.  make-lib does
not require bud.  It also supports GDC, you can run 'make-lib help' for more
information.

To build the examples, tools, tests, and the Allegro demo on Windows, use the
appropriately named batch files.  These batch files all require bud.

On Unix:
You need to compile the regular Allegro first, to get the library to link with.
Read the Allegro docs for how to do that.  To build the examples, and other
programs that come with DAllegro, just run 'make' with no arguments.



USAGE
-----
As an example, here's how to build the DBlocks demo game:
bud dblocks\dblocks.d alleg.lib

To build without bud, you can use the .lib file that make-lib creates.
You have to be in the dblocks directory for this to work:
dmd dblocks board block blocktypes -I..  alleg.lib ..\dalleg.lib

As you can see, bud makes things a lot simpler.  It pulls in all the files
that are needed, without any help.  And it doesn't need a precompiled version
of DAllegro, it's all compiled and linked automatically.

Check out the examples, and in particular DBlocks, to get started with D and
DAllegro.

D documentation starting points:
http://www.digitalmars.com/d/lex.html
http://www.digitalmars.com/d/phobos/phobos.html
http://www.prowiki.org/wiki4d/wiki.cgi?LanguageSpecification/KeywordIndex



LINKING WITH ALLEGRO
--------------------
With DMD on Windows, dynamically linking with Allegro is currently the
recommended way to go.  Static linking requires the (as of this writing
unreleased) 4.2.2 version of Allegro, as you need a .lib file that's compatible
with DMD.  Only DMC, the Digital Mars C++ compiler produces compatible .lib
files, and Allegro prior to 4.2.2 doesn't support DMC.

With GDC on Windows, and both compilers on linux, statically linking with
Allegro is believed to work.  On Windows, you have to build DAllegro with
-version=STATICLINK, otherwise it will expect the DLL version of Allegro.  On
linux, this doesn't matter.

For statically linking to an Allegro library built with DMC, you need both
-version=STATICLINK and -version=ALLEGRO_NO_ASM.  Both DMD and bud accepts
those arguments.



DIFFERENCES BETWEEN C AND D ALLEGRO
-----------------------------------
Most Allegro features works exactly like in C.  But there are some differences.

allegro_id is a char pointer, not a char array.  The same goes for
allegro_error, cpu_vendor, empty_string, and possibly others.  The compiler
will tell you if you get it wrong.

Most macros are just made functions, which should be fine in most cases.  The
ones that are likely to be used for static initialization will work as compile-
time functions.  Compile-time functions were introduced with DMD 1.006, but
some features need bug fixes that are in 1.007.  

Globals that are declared volatile has been put in property wrappers in D,
since D doesn't have volatile as a storage class, but as a statement.
Properties consist of a getter and/or a setter function, but you can use them
with variable syntax.  The difference is that the ++ and -- operators won't
work, and taking their address doesn't make much sense.

AL_RAND() is an alias for rand() from the standard C library. If you prefer to
use D's std.random.rand, be aware that it gives results in a different range.

set_palette() is  declared as taking RGB* instead of PALETTE as an argument.
It's then overloaded with a D wrapper that take PALETTE arguments. This allows
you to use it like you would in C.

al_long and al_ulong are aliases for types that are compatible with C longs for
each platform.  Use it when defining functions that are to be called by the C
lib, and have C longs as arguments.  D's int and long types have fixed sizes,
at least on 32 and 64 bit platforms.


=== ASSERT ===
In D, 'assert' is a keyword, and its use is integrated with the exception
handling system.  DAllegro does not use Allegro's al_assert(), but relies
exclusively on D's built-in assert feature.

If you want to link with the debug version of the Allegro C library, keep in
mind that that still uses al_assert().  Here's an example showing how to handle
both D's assert and Allegro's al_assert() in the same way:

---
import std.string : toStringz;

extern (C) int error_handler(char* msg)
{
    /* must set text mode before calling allegro_message() */
   set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
   allegro_message(msg);
   exit(1);
   return 1;
}

int main(char[][] args)
{
   try {
      // make al_assert call our error handler
      register_error_handler(&error_handler);

      /* ...your regular code goes here... */
   }
   catch (Object o) {  // catch all exceptions, including asserts
      error_handler(toStringz(o.toString()));
   }

   return 0;
}
---

If you don't do this, the uncaught exceptions will just get printed to stderr.
Which is ok as long as there is a console available.



USING THE PLATFORM-SPECIFIC APIS
--------------------------------

=== WINDOWS ===
To use the platform-specific API for Windows, you just import allegro.winalleg,
in addition to allegro.allegro.  Unlike C-Allegro, allegro.winalleg doesn't import
the Windows API, so you need to do that yourself.

The Windows header port that comes with Phobos (std.c.windows.windows) is very
incomplete.  For this reason, using allegro.winalleg, or building the
Windows-specific tests requires you to install the Windows API header port
available here:

http://www.prowiki.org/wiki4d/wiki.cgi?WindowsAPI

For Tango, it's recommended to use the modules in the tango.sys.win32 package.

If you decide to use other Windows API modules than the recommended ones, you'll
probably get some conflicting types, because allegro.winalleg uses the
recommended modules.

If you're used to using WinMain in C/C++, be aware that D requires
some extra initialization and cleanup code. See the examples in tests/win/ for
how to get started with dallegro and the Windows API.

=== UNIX ===
To get the xwin_set_window_name function, import allegro.xalleg.



GOTCHAS WHEN SWITCHING FROM C/C++ TO D
--------------------------------------

=== STRINGS ===
D string literals are by default dynamic char arrays.  But they are implicitly
converted to char pointers when used as initializers or function arguments.
However, this only works when the receiving type is known to be a char pointer,
not for variable argument lists.

This is okay:
puts("yeah");  // Using C's puts, found in std.c.stdio.

This is likely to crash:
printf("%s\n", "bummer");  // printf dereferences the length, not the pointer

Do this instead:
printf("%s\n", "yeah".ptr);  // .ptr is the pointer the data

Char arrays in D are not commonly null-terminated.  But string literals are
null-terminated, so if you haven't touched the end of the string, the null-
terminator will still be there.  In other cases, the easiest way is to use
std.string.toStringz().  toStringz copies the string, so when you need maximum
speed, you can just append a null yourself: str ~= '\0'.

Be aware that when you give D's writefln() a char*, it will print the address
instead of the string.  So remember to use std.string.toString() to convert to
a proper D string.  Or if you prefer C's printf(), it's always available when
using Phobos.

D char[] is utf-8.

If you need to get fancy with strings and Unicode handling, you might want to
read these pages:
http://www.prowiki.org/wiki4d/wiki.cgi?CharsAndStrs
http://www.prowiki.org/wiki4d/wiki.cgi?DanielKeep/TextInD



=== ERRNO ===
When using Phobos, import std.c.stdlib, and use getErrno() and setErrno().
For Tango, import tango.stdc.errno, and just use errno like you would in C.
Tango's errno is not an int, it's a set of property wrappers.  So you can't
take its address, since you'd get the address of the property function
instead.

If you need to use install_allegro() directly, be aware that the errno_ptr
argument is not used.  install_allegro() takes care of getting the address of
errno itself, since it has to be done in a system-specific way.  Just use
'null' for the argument.



=== STATIC INITIALIZATION ===
If you rely static initialization, you should know that not everything is
initialized to zero in D.

- Floating point types are initialized to NaN.
- char is initialized to 0xFF, wchar and dchar also have non-zero default
  initializers.

To initialize an array to all zeros:
float[3] vector = 0;
char[256] buffer = 0;

In any case, it's probably best to be explicit about initializers if your code
depends on their value.



CONDITIONAL COMPILATION
-----------------------

ALLEGRO_NO_ASM
    Since Allegro's assembly code has not been ported to D, this has a lot less
    impact then in C-Allegro.  This is a global constant, and it can also be
    enabled globally by just adding '-version=ALLEGRO_NO_ASM' to the command
    line.

Global constants that work like it says in the Allegro docs:
ALLEGRO_PLATFORM_STR
ALLEGRO_VRAM_SINGLE_SURFACE
ALLEGRO_CONSOLE_OK
ALLEGRO_NO_ASM
ALLEGRO_MULTITHREADED
ALLEGRO_LFN
OTHER_PATH_SEPARATOR
DEVICE_SEPARATOR

Version identifiers that work like it says in the Allegro docs:
STATICLINK
ALLEGRO_NO_COMPATIBILITY
ALLEGRO_NO_CLEAR_BITMAP_ALIAS
ALLEGRO_NO_FIX_ALIASES
ALLEGRO_NO_VHLINE_ALIAS

Global constants can be used with static if's to achieve conditional
compilation.  Version identifiers are for use with version statements, and has
to be given on the command line to work globally.  Version identifiers set in
one module has no effect on the compilation of other modules.

Most of the other Allegro #defines are covered by D's standard version
identifiers, the ones for DMD are listed on this page:
http://www.digitalmars.com/d/version.html.  GDC probably defines some more.



CREDITS
-------
- Shawn Hargreaves for creating Allegro.
- Walter Bright for creating the D language and the DMD compiler.
- Thanks to juvinious for help with getting dallegro to work on linux, and for
  translating some of the examples.
- Anders F. Bjorklund for help with the Mac OS X support.


LINKS
-----
Project web site: http://www.dsource.org/projects/dallegro
Author: torhu@yahoo.com
http://alleg.sf.net
http://www.allegro.cc
http://www.digitalmars.com/d/
